const pool = require("../config/database");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// ========================================
// VALIDATION HELPERS
// ========================================

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isValidEmail(email) {
    return typeof email === "string" && EMAIL_REGEX.test(email.trim());
}

function getPasswordError(password) {
    if (typeof password !== "string" || password.length < 8) {
        return "Password must be at least 8 characters long";
    }
    if (!/[A-Z]/.test(password)) {
        return "Password must contain at least one uppercase letter";
    }
    if (!/[0-9]/.test(password)) {
        return "Password must contain at least one number";
    }
    if (!/[^A-Za-z0-9]/.test(password)) {
        return "Password must contain at least one special character";
    }
    return null;
}

// ========================================
// REGISTER
// ========================================

const register = async (req, res) => {
    try {
        const {
            first_name,
            last_name,
            email,
            password,
            phone
        } = req.body;

        // NOTE: role_id is intentionally NOT read from req.body.
        // Letting clients set their own role_id is a privilege
        // escalation bug — it would let anyone register as an
        // admin/provider by POSTing role_id directly to the API.
        // Every self-registration is forced to pet_owner (1).
        // Elevated roles should be assigned separately by an
        // admin-only endpoint, not during public registration.

        // ----------------------------------------
        // Validate required fields
        // ----------------------------------------

        if (!first_name || !last_name || !email || !password) {
            return res.status(400).json({
                message:
                    "First name, last name, email, and password are required"
            });
        }

        if (!isValidEmail(email)) {
            return res.status(400).json({
                message: "Please enter a valid email address"
            });
        }

        const passwordError = getPasswordError(password);

        if (passwordError) {
            return res.status(400).json({
                message: passwordError
            });
        }

        // ----------------------------------------
        // Normalize email
        // ----------------------------------------

        const normalizedEmail = email.trim().toLowerCase();

        // ----------------------------------------
        // Check existing email
        // ----------------------------------------

        const [existingUsers] = await pool.query(
            `SELECT user_id
             FROM users
             WHERE email = ?`,
            [normalizedEmail]
        );

        if (existingUsers.length > 0) {
            return res.status(409).json({
                message: "Email is already registered"
            });
        }

        // ----------------------------------------
        // Hash password
        // ----------------------------------------

        const passwordHash = await bcrypt.hash(password, 10);

        // ----------------------------------------
        // Insert user (role_id hardcoded — see note above)
        // role_id 1 = pet_owner
        // ----------------------------------------

        const PET_OWNER_ROLE_ID = 1;

        try {
            const [result] = await pool.query(
                `INSERT INTO users
                (
                    role_id,
                    first_name,
                    last_name,
                    email,
                    password_hash,
                    phone
                )
                VALUES (?, ?, ?, ?, ?, ?)`,
                [
                    PET_OWNER_ROLE_ID,
                    first_name.trim(),
                    last_name.trim(),
                    normalizedEmail,
                    passwordHash,
                    phone || null
                ]
            );

            return res.status(201).json({
                message: "User registered successfully",
                user_id: result.insertId
            });

        } catch (insertError) {
            // Backstop for the race condition between the SELECT
            // check above and this INSERT: if two requests for the
            // same email land at nearly the same time, both can pass
            // the SELECT check before either INSERTs. A unique
            // constraint on users.email turns the second INSERT into
            // a clean, expected error instead of a duplicate row.
            if (insertError.code === "ER_DUP_ENTRY") {
                return res.status(409).json({
                    message: "Email is already registered"
                });
            }
            throw insertError;
        }

    } catch (error) {
        console.error("REGISTER ERROR:", error);

        return res.status(500).json({
            message: "Registration failed"
        });
    }
};

// ========================================
// LOGIN
// ========================================

const login = async (req, res) => {
    try {
        const {
            email,
            password
        } = req.body;

        // ----------------------------------------
        // Validate
        // ----------------------------------------

        if (!email || !password) {
            return res.status(400).json({
                message: "Email and password are required"
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        // ----------------------------------------
        // Find user
        // ----------------------------------------

        const [users] = await pool.query(
            `SELECT
                user_id,
                role_id,
                first_name,
                last_name,
                email,
                password_hash,
                phone,
                status
             FROM users
             WHERE email = ?`,
            [normalizedEmail]
        );

        if (users.length === 0) {
            return res.status(401).json({
                message: "Invalid email or password"
            });
        }

        const user = users[0];

        // ----------------------------------------
        // Check account status
        // ----------------------------------------

        if (user.status && user.status !== "active") {
            return res.status(403).json({
                message: `Account is ${user.status}`
            });
        }

        // ----------------------------------------
        // Check password
        // ----------------------------------------

        const passwordMatch = await bcrypt.compare(
            password,
            user.password_hash
        );

        if (!passwordMatch) {
            return res.status(401).json({
                message: "Invalid email or password"
            });
        }

        // ----------------------------------------
        // Check JWT secret
        // ----------------------------------------

        if (!process.env.JWT_SECRET) {
            console.error("JWT_SECRET is missing from .env");

            return res.status(500).json({
                message: "Server authentication configuration error"
            });
        }

        // ----------------------------------------
        // Create JWT
        // ----------------------------------------

        const token = jwt.sign(
            {
                user_id: user.user_id,
                role_id: user.role_id,
                email: user.email
            },
            process.env.JWT_SECRET,
            {
                expiresIn: "1d"
            }
        );

        // ----------------------------------------
        // Return user
        // ----------------------------------------

        return res.json({
            message: "Login successful",

            token,

            user: {
                user_id: user.user_id,
                role_id: user.role_id,
                first_name: user.first_name,
                last_name: user.last_name,
                email: user.email,
                phone: user.phone
            }
        });

    } catch (error) {
        console.error("LOGIN ERROR:", error);

        return res.status(500).json({
            message: "Login failed"
        });
    }
};

module.exports = {
    register,
    login
};