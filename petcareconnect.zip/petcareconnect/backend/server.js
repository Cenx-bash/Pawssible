const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config({
    path: path.join(__dirname, "../.env")
});

const pool = require("./config/database");

const authRoutes = require("./routes/auth.routes");
const petRoutes = require("./routes/pets.routes");

const app = express();

const PORT = process.env.PORT || 3000;

const frontendPath = path.join(
    __dirname,
    "../frontend"
);

// ========================================
// MIDDLEWARE
// ========================================

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ========================================
// FRONTEND HOME
// ========================================

// IMPORTANT:
// This must come BEFORE express.static()

app.get("/", (req, res) => {
    res.sendFile(
        path.join(frontendPath, "login.html")
    );
});

// ========================================
// FRONTEND PAGES
// ========================================

app.get("/login.html", (req, res) => {
    res.sendFile(
        path.join(frontendPath, "login.html")
    );
});

app.get("/register.html", (req, res) => {
    res.sendFile(
        path.join(frontendPath, "register.html")
    );
});

// ========================================
// STATIC FRONTEND FILES
// ========================================

app.use(
    express.static(frontendPath)
);

// ========================================
// API
// ========================================

app.get("/api", (req, res) => {
    res.json({
        message: "PetCareConnect API is running",
        status: "success",
        endpoints: {
            auth: "/api/auth",
            login: "/api/auth/login",
            register: "/api/auth/register",
            pets: "/api/pets",
            database: "/api/test-db"
        }
    });
});

// ========================================
// AUTH ROUTES
// ========================================

app.use(
    "/api/auth",
    authRoutes
);

// ========================================
// PET ROUTES
// ========================================

app.use(
    "/api/pets",
    petRoutes
);

// ========================================
// DATABASE TEST
// ========================================

app.get("/api/test-db", async (req, res) => {
    try {

        const [rows] = await pool.query(
            "SELECT 1 AS result"
        );

        res.json({
            message: "Database connection successful",
            database: "petcareconnect",
            result: rows[0].result
        });

    } catch (error) {

        console.error(
            "DATABASE ERROR:",
            error
        );

        res.status(500).json({
            message: "Database connection failed",
            error: error.message
        });
    }
});

// ========================================
// STATUS
// ========================================

app.get("/api/status", (req, res) => {
    res.json({
        application: "PetCareConnect",
        server: "running",
        port: PORT
    });
});

// ========================================
// 404
// ========================================

app.use((req, res) => {
    res.status(404).json({
        message: "Route not found",
        path: req.originalUrl,
        method: req.method
    });
});

// ========================================
// ERROR HANDLER
// ========================================

app.use((error, req, res, next) => {

    console.error(
        "SERVER ERROR:",
        error
    );

    res.status(500).json({
        message: "Internal server error",
        error: error.message
    });
});

// ========================================
// START
// ========================================

app.listen(
    PORT,
    "0.0.0.0",
    () => {

        console.log("");
        console.log("=================================");
        console.log("       PetCareConnect");
        console.log("=================================");
        console.log(
            `Server:   http://localhost:${PORT}`
        );
        console.log(
            `Login:    http://localhost:${PORT}/login.html`
        );
        console.log(
            `Register: http://localhost:${PORT}/register.html`
        );
        console.log(
            `API:      http://localhost:${PORT}/api`
        );
        console.log(
            `Database: http://localhost:${PORT}/api/test-db`
        );
        console.log("=================================");
        console.log("");
    }
);