const express = require("express");

const {
    register,
    login
} = require("../controllers/auth.controller");

const router = express.Router();

// ========================================
// AUTH ROUTE TEST
// ========================================

router.get("/", (req, res) => {
    res.json({
        message: "PetCareConnect Auth API is working"
    });
});

// ========================================
// REGISTER
// ========================================

router.post("/register", register);

// ========================================
// LOGIN
// ========================================

router.post("/login", login);

module.exports = router;