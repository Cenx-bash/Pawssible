const mysql = require("mysql2/promise");
require("dotenv").config();

const pool = mysql.createPool({
    host: "127.0.0.1",
    port: 3306,
    user: process.env.DB_USER || "petcare",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "petcareconnect",

    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Test connection
pool.getConnection()
    .then(connection => {
        console.log("MySQL connected successfully");
        connection.release();
    })
    .catch(error => {
        console.error("MySQL connection failed:");
        console.error(error.message);
    });

module.exports = pool;
